public class Produit {
    //data
    private String codeProd;
    private String name;
    private int quantity;
    private int priceUnit;
    private int secureStock;
    private Categorie categorie;
    //builders
    public Produit(String codeProd, String name, int quantity, int priceUnit, int secureStock, Categorie pCategorie)
    {
        this.codeProd = codeProd;
        this.name = name;
        this.quantity = quantity;
        this.priceUnit = priceUnit;
        this.secureStock = secureStock;
        this.categorie = categorie;
    }

    public Produit (String codeProd, String name, int quantity){
        this.codeProd = codeProd;
        this.name = name;
        this.quantity = quantity;
    }

    //getters


    public String getCodeProd() {
        return codeProd;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getPriceUnit() {
        return priceUnit;
    }

    public int getSecureStock() {
        return secureStock;
    }

    //setters

    public void setQuantity(int quantityNew) {
        quantity = quantityNew;
        if(quantity <= secureStock){
            System.out.println("La quantité de produits est inférieur ou égale à la quantité de sécurité");
        }
    }

    public void setPriceUnit(int priceUnit) {
        this.priceUnit = priceUnit;
    }

    public void setSecureStock(int secureStock) {
        this.secureStock = secureStock;
    }

    //functions
    public int stockWorth(){
        int worth = priceUnit*quantity;
        return worth;
    }
    public void possibilityOrder(int orderedQuantity){
        if (orderedQuantity > quantity){
            System.out.println("Commande moins steuplai");
        }
        else if(orderedQuantity == quantity){
            System.out.println("C'est possible mais plus de stock");
        }
        else{
            System.out.println("Commande possible");
        }
    }



}
