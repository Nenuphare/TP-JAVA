public class Categorie
{
    private String codeCategorie;
    private String nomCategorie;

    public Categorie(String CodeCategorie, String NomCategorie)
    {
        this.codeCategorie = codeCategorie;
        this.nomCategorie = nomCategorie;
    }

    public String getCodeCategorie()
    {
        return codeCategorie;
    }

    public void setCodeCategorie(String codeCategorie)
    {
        this.codeCategorie = codeCategorie;
    }

    public String getNomCategorie()
    {
        return nomCategorie;
    }

    public void setNomCategorie(String nomCategorie)
    {
        this.nomCategorie = nomCategorie;
    }
}